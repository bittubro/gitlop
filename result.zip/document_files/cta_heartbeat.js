$(function () {

    let ctaButton = $(".hcb-button-cta");

    ctaButton.addClass('heartbeat');

    let heartBeatInterval = setInterval(() => {

        //check if there are other buttons with heartbeat, but are not cta butotns

        $(".heartbeat").each(function () {
            if (!$(this).hasClass('hcb-button-cta')) {
                $(this).removeClass('heartbeat');
            }
        });


        //update the current cta button
        ctaButton = $(".hcb-button-cta");
        if (ctaButton.hasClass('heartbeat')) {
            ctaButton.removeClass('heartbeat')
        } else {
            ctaButton.addClass('heartbeat');
        }
    }, 3000)


});

